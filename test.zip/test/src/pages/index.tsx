import Image from "next/image";
import { Geist, Geist_Mono } from "next/font/google";
import CardCarousel from "@/components/CardCarousel";
import WhoWeAre from "@/components/WhoWeAre";
import Services from "@/components/Services";
import HeroSection from "@/components/HeroSection";
import MissionSection from "@/components/MissionSection";
import Testimonials from "@/components/Testimonials";
import ContactUs from "@/components/ContactUs";
import Footer from "@/components/Footer";
import Slide from "@/components/SlideCrousel";
import Navbar from "@/components/Navbar";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export default function Home() {
  return (
    <>
      <Navbar />

      <main>

        <Slide />

        <div className="w-3/4 mx-auto px-4 py-28">
      <CardCarousel />
    </div>
    <WhoWeAre />
    <Services />
    <HeroSection />
    <MissionSection />
    <Testimonials />
    <ContactUs />
      </main>
      <footer>
        <Footer />
      </footer>
    </>
  );
}
