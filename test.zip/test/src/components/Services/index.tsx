import { AiOutlineMail } from "react-icons/ai";
import { CiMobile3, CiMonitor } from "react-icons/ci";
import { GoDash } from "react-icons/go";
import { GrGroup } from "react-icons/gr";

const Services = () => {
  return (
    <section className="bg-[#0a0f1d] text-white py-16 px-4 overflow-hidden bg-cover bg-no-repeat"
      style={{
        backgroundImage: "url('/images/shape-tm-14-old.jpg')", // Local image path, assuming it's in public/images
      }}>
      <div className="max-w-7xl mx-auto text-center">
        <div className="flex text-blue-400 justify-center">
          <h3 className=" uppercase my-auto tracking-wide text-sm">What We Offering</h3>
          <GoDash className="size-8" />
        </div>
        <h2 className="text-5xl font-bold mt-2">
          We offer <span className="text-white">premium services</span> <br />
          <span className="text-white">Exclusively for you.</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mt-12">
          {services.map((service, index) => (
            <div key={index} className="border border-gray-700 p-8 rounded-lg text-center hover:shadow-lg transition">
              <div className="flex justify-center mb-4">
                {service.icon}
              </div>
              <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
              <p className="text-gray-400 mb-4">{service?.dec}</p>
              <a href="#" className="text-blue-400 font-semibold inline-flex items-center">
                Read more <span className="ml-2">&rarr;</span>
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const services = [
  {
    title: "Website Development",
    dec:"Modern, user-friendly, and responsive website development.",
    icon: <CiMonitor  className="size-24 text-white font-thin text" /> , // Place this file in /public/icons
  },
  {
    title: "Social Media Marketing",
    dec:"Boost followers, engagement, and conversions.",
    icon: <GrGroup  className="size-24 text-white font-thin text" />,
  },
  {
    title: "Email Marketing",
    dec:"Use precise targeting for higher engagement",
    icon: <AiOutlineMail className="size-24 text-white stroke-[0.5]"  />,
  },
  {
    title: "Mobile Marketing",
    dec:"Expand your brand’s visibility and reach.",
    icon: <CiMobile3 className="size-24 text-white font-thin text" />,
  },
];

export default Services;
