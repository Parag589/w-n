import Image from "next/image";
import { GoDash } from "react-icons/go";

const WhoWeAre = () => {
  return (
    <div id="aboutUs" className="bg-white min-h-screen flex items-center justify-center overflow-hidden bg-no-repeat"
      style={{
        backgroundImage: "url('/images/shape-tm-11.png')", // Local image path, assuming it's in public/images
      }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 items-center justify-center">
        {/* Content Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-40">
          {/* Left Column */}

          <div className="flex flex-col items-center justify-center space-y-6">
            <Image src="/images/who-are-we.png" alt="Who We Are" width={550} height={700} />
          </div>

          {/* Right Column */}
          <div className="space-y-6 my-auto">
            <div className="text-start  flex text-blue-600">
              <h1 className="text-sm my-auto mt-2 font-thin">WHO WE ARE</h1> 
              <GoDash className="size-8"/>
            </div>
              <p className="text-5xl font-bold">We provide the world class solutions.</p>

            <p className="text-lg text-gray-700">At WCTS Digital Pvt. Ltd., we offer 360-degree web design and digital marketing solutions to help businesses establish a strong online presence and achieve sustainable growth. </p>
            <div className="space-y-4">
            <div className="flex items-center space-x-4">
                <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                <p className="text-lg text-gray-700">9+ years of experience across 11+ industries.</p>
              </div>
              <div className="flex items-center space-x-4">
                <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                <p className="text-lg text-gray-700">Successfully worked with 40+ businesses worldwide.</p>
              </div>
              <div className="flex items-center space-x-4">
                <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                <p className="text-lg text-gray-700">Deliver perfect solutions for business.</p>
              </div>
              <div className="flex items-center space-x-4">
                <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                <p className="text-lg text-gray-700">Readily work with global brands solutions.</p>
              </div>
              <div className="flex items-center space-x-4">
                <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                <p className="text-lg text-gray-700">Residential business installation.</p>
              </div>
              
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WhoWeAre;
