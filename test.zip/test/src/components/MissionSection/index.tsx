'use client';

import Image from 'next/image';
import { GoDash } from 'react-icons/go';

export default function MissionSection() {
  return (
    <section className="flex flex-col md:flex-row items-center bg-gray-100 overflow-hidden bg-cover bg-no-repeat"
      style={{
        backgroundImage: "url('/images/shape-tm-3.png')", // Change to your desired image URL
      }}>
      <div className="md:w-1/2 relative h-full">
        <Image 
          src="/images/IT-Services.png"
          alt="Team Meeting"
          width={800}
          height={600}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="w-full md:w-1/2 p-10">
      <div className='flex text-blue-600'>
        <h5 className="font-thin text-sm uppercase my-auto">Why Choose Us</h5>
          <GoDash className="size-8"/> 
      </div>
        <h2 className="text-5xl font-bold text-gray-900 mt-2">
          Our mission is to provide <br /> Worldclass Solutions.
        </h2>
        <p className="text-gray-600 mt-4">
          Our passionate professionals craft tailored, high-quality systems to meet your unique needs and deliver effective solutions.
        </p>
        <div className="mt-6">
          <p className="text-lg font-semibold text-gray-900 flex items-center">
            <span className="mr-2">
              {/* 💡 */}
              </span> For Your Specific Industry We Have Smart Idea For Business Goal.
          </p>
          <ul className="mt-4 space-y-2">
            <li className="flex items-center text-gray-700">
            <span className="w-2 h-2 m-2 bg-blue-500 rounded-full"></span>

              Reach Your Target Audience
            </li>
            <li className="flex items-center text-gray-700">
            <span className="w-2 h-2 m-2 bg-blue-500 rounded-full"></span>

              Increase Your Digital Footfall
            </li>
            <li className="flex items-center text-gray-700">
            <span className="w-2 h-2 m-2 bg-blue-500 rounded-full"></span>

              Stay Ahead of Trends & Competition
            </li>
          </ul>
        </div>
      </div>
    </section>
  );
}
