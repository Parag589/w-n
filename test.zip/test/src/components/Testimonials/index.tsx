import { FaStar } from "react-icons/fa";

export default function Testimonials() {
  const testimonials = [
    {
      name: "John Doe",
      quote: "Absolutely love the product! The quality is top-notch.",
      image: "https://randomuser.me/api/portraits/men/11.jpg",
    },
    {
      name: "Sarah Johnson",
      quote: "Fast delivery and great service. Highly recommend!",
      image: "https://randomuser.me/api/portraits/women/22.jpg",
    },
    {
      name: "Michael Smith",
      quote: "Exceeded my expectations! Will definitely order again.",
      image: "https://randomuser.me/api/portraits/men/33.jpg",
    },
    {
      name: "Emma Brown",
      quote: "Amazing experience! Customer support was very helpful.",
      image: "https://randomuser.me/api/portraits/women/44.jpg",
    },
    {
      name: "David Wilson",
      quote: "Best purchase I’ve made this year! 5 stars from me!",
      image: "https://randomuser.me/api/portraits/men/55.jpg",
    },
  ];

  return (
    <section
      id="testimonials"
      className="relative py-20 sm:py-32 overflow-hidden bg-center bg-no-repeat"
      style={{
        backgroundImage: "url('/images/dotted-map-4.png')", // Change to your desired image URL
      }}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl md:text-center">
          <h2 className="font-display text-5xl tracking-tight text-slate-900 sm:text-4xl">
            What Our Customers Are Saying
          </h2>
        </div>

        {/* Scrolling Container */}
        <div className="relative mt-16 w-full overflow-hidden">
          <div className="flex w-max gap-8 animate-scroll">
            {/* Original and Duplicated Testimonials */}
            {[...testimonials, ...testimonials].map((testimonial, i) => (
              <div key={i} className="w-96 h-aut0 flex-shrink-0 bg-white p-6 mb-10 shadow-xl shadow-slate-900/10 rounded-2xl">
                <blockquote className="relative">
                  <p className="text-sm tracking-tight text-slate-900">
                    {testimonial.quote}
                  </p>
                </blockquote>
                {/* Golden Stars */}
                <div className="mt-4 flex">
                  {[...Array(5)].map((_, i) => (
                    <FaStar key={i} className="text-yellow-500 text-sm" />
                  ))}
                </div>
                <figcaption className="relative mt-2 flex items-center justify-between border-t border-slate-100 pt-2">
                  <div>
                    <div className="font-display text-base text-slate-900">{testimonial.name}</div>
                  </div>
                  <div className="overflow-hidden rounded-full bg-slate-50">
                    <img alt="" className="h-8 w-8 object-cover" src={testimonial.image} />
                  </div>
                </figcaption>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tailwind CSS Animation */}
      <style jsx>{`
        @keyframes scroll {
          from {
            transform: translateX(0);
          }
          to {
            transform: translateX(-50%);
          }
        }
        .animate-scroll {
          display: flex;
          animation: scroll 20s linear infinite;
        }
      `}</style>
    </section>
  );
}
