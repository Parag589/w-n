import Image from "next/image";
import { useState } from "react";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  // Function to enable/disable scrolling
  const toggleScroll = (disable: boolean) => {
    document.body.style.overflow = disable ? "hidden" : "auto";
  };

  // Toggle menu & scrolling
  const toggleMenu = () => {
    setIsOpen(!isOpen);
    toggleScroll(!isOpen);
  };

  // Scroll smoothly to the section & close menu
  const handleLinkClick = (id: string) => {
    const section = document.getElementById(id);
    if (section) {
      section.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    setIsOpen(false);
    toggleScroll(false);
  };

  return (
    <nav className="bg-white border-gray-200 dark:bg-gray-900">
      <div className="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
        {/* Logo */}
        <a href="#" className="flex items-center space-x-3">
          <span className="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">
            <Image src={'/images/logo.png'} width={200} height={80} alt='logo'/>
          </span>
        </a>

        {/* Desktop Navbar */}
        <div className="hidden md:flex space-x-8">
          <button onClick={() => handleLinkClick("home")} className="text-gray-900 dark:text-white hover:text-blue-700">
            Home
          </button>
          <button onClick={() => handleLinkClick("aboutUs")} className="text-gray-900 dark:text-white hover:text-blue-700">
            About Us
          </button>
          <button onClick={() => handleLinkClick("contactUs")} className="text-gray-900 dark:text-white hover:text-blue-700">
            Contact Us
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button
          onClick={toggleMenu}
          type="button"
          className="md:hidden p-2 w-10 h-10 text-gray-500 rounded-lg hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600"
          aria-expanded={isOpen}
        >
          <span className="sr-only">Open main menu</span>
          <svg
            className="w-6 h-6"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            {isOpen ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16m-7 6h7" />
            )}
          </svg>
        </button>
      </div>

      {/* Mobile Shutter Menu */}
      <div
        className={`absolute top-0 left-0 bg-white dark:bg-gray-900 z-50 p-6 shadow-lg transition-transform duration-300 ease-in-out ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        } w-auto h-full`}
      >
        <ul className="flex flex-col space-y-6 mt-6">
          <li>
            <button className="text-lg text-gray-900 dark:text-white hover:text-blue-700" onClick={() => handleLinkClick("home")}>
              Home
            </button>
          </li>
          <li>
            <button className="text-lg text-gray-900 dark:text-white hover:text-blue-700" onClick={() => handleLinkClick("aboutUs")}>
              About Us
            </button>
          </li>
          <li>
            <button className="text-lg text-gray-900 dark:text-white hover:text-blue-700" onClick={() => handleLinkClick("contactUs")}>
              Contact Us
            </button>
          </li>
        </ul>

        {/* Close Button */}
        <button onClick={toggleMenu} className="absolute top-4 right-4 text-gray-900 dark:text-white text-2xl">
          ✖
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
