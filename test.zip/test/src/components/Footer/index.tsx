"use client";

import Link from "next/link";
import { FaFacebook, FaInstagram, FaYoutube, FaWhatsapp, FaBuilding, FaMapMarkerAlt, FaEnvelope, FaPhone } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-gray-300 py-8 px-4">
      <div className="w-3/4 mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-8">
          {/* Quick Contact */}
          <div>
            <h3 className="text-white text-lg font-semibold">Quick Contact</h3>
            <p className="mt-2 flex items-center">
              <FaBuilding className="mr-3" /> WCTS Digital
            </p>
            <p className="mt-2 flex items-start">
              <FaMapMarkerAlt className="mr-3 mt-1" />
              GTFTF20802 GODREJ 24 TOWER F2 <br /> MULSHI PUNE Hinjewadi (CT) 411057
            </p>
            <p className="mt-2 flex items-center">
              <FaEnvelope className="mr-3" /> info@wctsdigital.com
            </p>
            <p className="mt-2 flex items-center">
              <FaPhone className="mr-3 rotate-90" /> +91 8279496114
            </p>
          </div>

          {/* General Links */}
          <div className="lg:mx-auto">
            <h3 className="text-white text-lg font-semibold">General Links</h3>
            <ul className="mt-2 space-y-2">
              <li>
                <Link href="#" className="hover:text-white">
                  Home
                </Link>
              </li>
              <li>
                <Link href="#aboutUs" className="hover:text-white">
                  About us
                </Link>
              </li>
              <li>
                <Link href="#contactUs" className="hover:text-white">
                  Contact us
                </Link>
              </li>
            </ul>
          </div>

          {/* Social Links */}
          <div className="lg:text-center">
            <h3 className="text-white text-lg font-semibold">Follow Us</h3>
            <div className="mt-4 flex lg:justify-center space-x-4">
              <a href="#" className="text-gray-400 hover:text-white text-xl">
                <FaFacebook />
              </a>
              <a href="#" className="text-gray-400 hover:text-white text-xl">
                <FaInstagram />
              </a>
              <a href="#" className="text-gray-400 hover:text-white text-xl">
                <FaYoutube />
              </a>
              <a href="https://wa.me/8279496114" className="text-gray-400 hover:text-white text-xl">
                <FaWhatsapp />
              </a>
            </div>
          </div>
        </div>

        <hr className="border-gray-700 my-6" />

        <div className="text-center">
          <p>
            This Site Is Managed By <span className="font-semibold">WCTS Digital</span>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
