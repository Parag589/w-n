import { LuMonitorSmartphone } from "react-icons/lu";
import { HiOutlineUserGroup } from "react-icons/hi";
import { MdOutlineAlternateEmail } from "react-icons/md";
import { HiMiniDevicePhoneMobile } from "react-icons/hi2";
import { IoIosGlobe } from "react-icons/io";

const services = [
  { id: 1, content: "Website Development", icon: <LuMonitorSmartphone className="w-16 h-16 text-blue-600" /> },
  { id: 2, content: "Social Media Marketing", icon: <HiOutlineUserGroup className="w-16 h-16 text-blue-600" /> },
  { id: 3, content: "Email Marketing", icon: <MdOutlineAlternateEmail className="w-16 h-16 text-blue-600" /> },
  { id: 4, content: "Mobile Marketing", icon: <HiMiniDevicePhoneMobile className="w-16 h-16 text-blue-600" /> },
  { id: 5, content: "Online Advertising", icon: <IoIosGlobe className="w-16 h-16 text-blue-600" /> },
];

const ResponsiveCards = () => {
  return (
    <div className="container mx-auto px-4">
     

      {/* Responsive Grid Layout */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 px-6">
        {services.map((service) => (
          <div key={service.id} className="bg-white p-6 shadow-lg border-t-8 border-blue-600 text-center overflow-hidden bg-cover bg-no-repeat"
               style={{
                 backgroundImage: "url('/images/shape-tm-1.png')",
               }}
             >
            <div className="flex justify-center">{service.icon}</div>
            <p className="mt-4 text-lg font-semibold">{service.content}</p>
          </div>
        ))}
      </div>

       {/* Heading & Button */}
       <div className="mx-auto text-center flex flex-col md:flex-row p-8 justify-center items-center">
        <h1 className="text-slate-600 text-xl font-semibold text-center">
          IT Technology services built specifically for your business.
        </h1>
        <button className="bg-blue-600 text-white px-4 py-2 font-bold mt-4 md:mt-0 md:ml-4">
          Find Your Solution
        </button>
      </div>
    </div>
  );
};

export default ResponsiveCards;









// import { LuMonitorSmartphone } from "react-icons/lu";
// import { HiOutlineUserGroup } from "react-icons/hi";
// import { MdOutlineAlternateEmail } from "react-icons/md";
// import { HiMiniDevicePhoneMobile } from "react-icons/hi2";
// import { IoIosGlobe } from "react-icons/io";

// const services = [
//   { id: 1, content: "Website Development", icon: <LuMonitorSmartphone className="w-16 h-16 text-blue-600" /> },
//   { id: 2, content: "Social Media Marketing", icon: <HiOutlineUserGroup className="w-16 h-16 text-blue-600" /> },
//   { id: 3, content: "Email Marketing", icon: <MdOutlineAlternateEmail className="w-16 h-16 text-blue-600" /> },
//   { id: 4, content: "Mobile Marketing", icon: <HiMiniDevicePhoneMobile className="w-16 h-16 text-blue-600" /> },
//   { id: 5, content: "Online Advertising", icon: <IoIosGlobe className="w-16 h-16 text-blue-600" /> },
// ];

// const ResponsiveCards = () => {
//   return (
//     <div className="container mx-auto px-4">
//       {/* Heading & Button */}
//       <div className="mx-auto text-center flex flex-col md:flex-row p-8 justify-center items-center">
//         <h1 className="text-slate-600 text-xl font-semibold">
//           IT Technology services built specifically for your business.
//         </h1>
//         <button className="bg-blue-600 text-white px-4 py-2 font-bold mt-4 md:mt-0 md:ml-4">
//           Find Your Solution
//         </button>
//       </div>

//       {/* Responsive Grid Layout */}
//       <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 px-6">
//         {services.map((service) => (
//           <div key={service.id} className="bg-white p-6 shadow-lg border-t-8 border-blue-600 text-center rounded-lg">
//             <div className="flex justify-center">{service.icon}</div>
//             <p className="mt-4 text-lg font-semibold">{service.content}</p>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };

// export default ResponsiveCards;










// import React, { useState, useRef } from "react";
// import { LuMonitorSmartphone } from "react-icons/lu";
// import { HiOutlineUserGroup } from "react-icons/hi";
// import { MdOutlineAlternateEmail } from "react-icons/md";
// import { HiMiniDevicePhoneMobile } from "react-icons/hi2";
// import { IoIosGlobe } from "react-icons/io";

// const CardCarousel = () => {
//   const [currentIndex, setCurrentIndex] = useState(0);
//   const [startX, setStartX] = useState(null);
//   const carouselRef = useRef(null);

//   const cards = [
//     { id: 1, content: "Website Development", icon: <LuMonitorSmartphone className="w-16 h-16 text-blue-600" /> },
//     { id: 2, content: "Social Media Marketing", icon: <HiOutlineUserGroup className="w-16 h-16 text-blue-600" /> },
//     { id: 3, content: "Email Marketing", icon: <MdOutlineAlternateEmail className="w-16 h-16 text-blue-600" /> },
//     { id: 4, content: "Mobile Marketing", icon: <HiMiniDevicePhoneMobile className="w-16 h-16 text-blue-600 font-bold" /> },
//     { id: 5, content: "Online Advertising", icon: <IoIosGlobe className="w-16 h-16 text-blue-600" /> },
//   ];

//   const nextSlide = () => {
//     setCurrentIndex((prevIndex) => (prevIndex + 1) % cards.length);
//   };

//   const prevSlide = () => {
//     setCurrentIndex((prevIndex) => (prevIndex - 1 + cards.length) % cards.length);
//   };

//   // Touch event handlers for swipe
//   const handleTouchStart = (e: any) => {
//     setStartX(e.touches[0].clientX);
//   };

//   const handleTouchMove = (e: any) => {
//     if (!startX) return;

//     const currentX = e.touches[0].clientX;
//     const diffX = startX - currentX;

//     if (Math.abs(diffX) > 50) {
//       if (diffX > 0) {
//         nextSlide(); // Swipe left
//       } else {
//         prevSlide(); // Swipe right
//       }
//       setStartX(null); // Reset startX after swipe
//     }
//   };

//   const handleTouchEnd = () => {
//     setStartX(null);
//   };

//   return (
//     <div className="relative overflow-hidden " ref={carouselRef} onTouchStart={handleTouchStart} onTouchMove={handleTouchMove} onTouchEnd={handleTouchEnd}>
//       {/* Carousel Container */}
//       <div
//         className="flex transition-transform duration-300 ease-in-out"
//         style={{
//           transform: `translateX(-${currentIndex * (100 / 4)}%)`,
//         }}
//       >
//         {cards.map((card) => (
//           <div
//             key={card.id}
//             className="flex-shrink-0 w-56 p-4" // Responsive widths
//           >
//             <div
//               className="bg-white p-4 py-8 h-48 shadow-lg font-bold border-t-8 border-blue-600 overflow-hidden bg-cover bg-no-repeat"
//               style={{
//                 backgroundImage: "url('/images/shape-tm-1.png')", // Local image path, assuming it's in public/images
//               }}
//             >
//               <div className="w-20 h-20 justify-center align-middle mx-auto">{card?.icon}</div>
//               <p className="mt-4 text-sm text-center justify-end">{card.content}</p>
//             </div>
//           </div>
//         ))}
//       </div>
//       <div className="mx-auto text-center flex flex-col md:flex-row p-8 justify-center items-center">
//   <h1 className="text-slate-600 text-lg text-xl">
//     IT Technology services built specifically for your business.
//   </h1>
//   <div className="bg-blue-600 text-white px-4 py-2 font-bold mt-4 md:mt-0 md:ml-4">
//     Find Your Solution
//   </div>
// </div>
//     </div>
//   );
// };

// export default CardCarousel;





