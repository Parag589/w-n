import Image from "next/image";

const HeroSection = () => {
  return (
    <section className="relative w-full h-auto flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 w-full h-full">
        <Image
          src="/images/6.jpg" // Place the image in /public folder
          alt="Hero Background"
          layout="fill"
          objectFit="cover"
          quality={100}
          className="opacity-80"
        />
      </div>
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/50"></div>
      
      {/* Content */}
      <div className="px-96 py-32 my-10 text-center text-white z-10 border border-opacity-40 border-gray-400">
        <h1 className="text-3xl md:text-5xl font-bold leading-tight">
          IT Solutions & Services Right <br /> At Your Fingertips
        </h1>
        
        <button className="mt-6 px-12 py-4 bg-blue-600 hover:bg-blue-700 text-white text-sm font-thin shadow-lg transition">
          DISCOVER MORE
        </button>
      </div>
    </section>
  );
};

export default HeroSection;
