import Image from "next/image";
import { FaEnvelope } from "react-icons/fa";
import { GoDash } from "react-icons/go";

export default function ContactUs() {
  return (
    <div id='contactUs'
      className="flex flex-col md:flex-row items-stretch overflow-hidden bg-cover bg-no-repeat"
      style={{
        backgroundImage: "url('/images/shape-tm-12.png')", // Local image path, assuming it's in public/images
      }}
    >
      {/* Left Image Section */}
      <div className="md:w-1/2 w-full relative">
        <Image src={"/images/image-9.png"} height={550} width={700} alt="contact us" />
      </div>

      {/* Right Content Section */}
      <div className="md:w-1/2 w-full p-8 flex flex-col justify-center">
        {/* Small Subtitle */}
        <div className="flex text-blue-600">
        <h6 className="text-sm font-thin uppercase tracking-widest my-auto">Contact Us</h6>
         <GoDash className="size-8"/>
        
        </div>

        {/* Main Title */}
        <h1 className="text-4xl font-bold mb-4 leading-tight">
          Contact Us Let’s Talk <br /> Your Any Query.
        </h1>

        {/* Description Paragraph */}
        <p className="text-gray-600 mb-6">At WCTS Digital, we’re here to help you with all your technology needs. Whether you have questions, need support, or want to discuss a project, our team is ready to assist you.</p>

        {/* Call Us text */}
        <p className="text-gray-700 mb-4">
          Or You may <span className="font-semibold">Call Us</span> For Appointment
        </p>

        {/* Phone Button + Number */}
        <div className="flex items-center mb-6">
          <div className=" text-blue-600 w-8">
            <span className="text-lg">&#x260E;</span>
          </div>
          <span className="text-lg font-medium">+91 8279496114</span>
        </div>
        <div className="flex items-center mb-6">
          <div className=" text-blue-600 w-8">
            <span className="text-lg"><FaEnvelope /></span>
          </div>
          <span className="text-lg font-medium">info@wctsdigital.com</span>
        </div>
        
      </div>
    </div>
  );
}
