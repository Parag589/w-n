(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_index_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_index_5771e1._.js",
  "chunks": [
    "static/chunks/[root of the server]__30fdaf._.js",
    "static/chunks/node_modules_next_2f973b._.js",
    "static/chunks/node_modules_react-dom_82bb97._.js",
    "static/chunks/node_modules_react-icons_lu_index_mjs_c31279._.js",
    "static/chunks/node_modules_react-icons_hi_index_mjs_5c5deb._.js",
    "static/chunks/node_modules_react-icons_md_index_mjs_57194a._.js",
    "static/chunks/node_modules_react-icons_hi2_index_mjs_6d8a1b._.js",
    "static/chunks/node_modules_react-icons_io_index_mjs_0372f8._.js",
    "static/chunks/node_modules_react-icons_go_index_mjs_e41599._.js",
    "static/chunks/node_modules_react-icons_ci_index_mjs_5b809b._.js",
    "static/chunks/node_modules_react-icons_gr_index_mjs_d87fc2._.js",
    "static/chunks/node_modules_react-icons_ai_index_mjs_2e83ab._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_bad01e._.js",
    "static/chunks/node_modules_react-icons_lib_75a63d._.js",
    "static/chunks/node_modules_ed065b._.js",
    "static/chunks/[next]_internal_font_google_c6a0bf._.css"
  ],
  "source": "entry"
});
